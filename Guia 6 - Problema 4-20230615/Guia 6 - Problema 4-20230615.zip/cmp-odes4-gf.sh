gfortran modulos/modulo-ISO-Fortran.f90 \
         modulos/modulo-constantes-p4.f90 \
         modulos/modulo-funciones-p4.f90 \
         modulos/modulo-rk4.f90 \
              p_odes4.f90 -o p_odes4.x

echo
